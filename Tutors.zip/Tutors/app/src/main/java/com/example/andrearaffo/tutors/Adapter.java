package com.example.andrearaffo.tutors;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.ClearCacheRequest;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.signature.StringSignature;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Andrea Raffo on 19/12/2017.
 */

public class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    final Context context;
    JSONArray list;
    RecyclerView recyclerView;
    ArrayList<TData> dataList;
    ArrayList<TData> tempList;
    private  RequestQueue queue;
    private String url;
    private String current;
    private LayoutInflater inflater;

    private final View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            SharedPreferences sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
            final String email = sharedPref.getString("email","");

            int itemPosition = recyclerView.getChildLayoutPosition(v);
            final String subject = tempList.get(itemPosition).subject;
            final String paidUserEmail = tempList.get(itemPosition).email;
            final String name = tempList.get(itemPosition).name;
            final String surname = tempList.get(itemPosition).surname;
            final String date = tempList.get(itemPosition).date;
            final String max = tempList.get(itemPosition).max;
            final String price = tempList.get(itemPosition).price;
            final String location = tempList.get(itemPosition).location;
            final String id = tempList.get(itemPosition).id;


            Response.Listener<String> responseListener = new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        boolean success = jsonResponse.getBoolean("success");
                        if (success) {
                            if(!jsonResponse.getString("current").isEmpty()){
                                current = jsonResponse.getString("current");
                                Log.d("LUL",current);

                                Bundle data = new Bundle();
                                data.putString("subject", subject);
                                data.putString("paidUserEmail", paidUserEmail);
                                data.putString("name", name);
                                data.putString("surname", surname);
                                data.putString("date", date);
                                data.putString("max", max);
                                data.putString("price", price);
                                data.putString("location", location);
                                data.putString("current", current);
                                data.putString("id", id);

                                FragmentManager fragmentManager = ((Activity) context).getFragmentManager();
                                FragmentTransaction transaction = fragmentManager.beginTransaction();

                                if(!email.equals(paidUserEmail)) {
                                    InfoFragment infoFragment = new InfoFragment();
                                    infoFragment.setArguments(data);
                                    transaction.replace(R.id.content, infoFragment).commit();
                                }else{
                                    PrivateInfoFragment privateinfoFragment = new PrivateInfoFragment();
                                    privateinfoFragment.setArguments(data);
                                    transaction.replace(R.id.content, privateinfoFragment).commit();
                                }
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            };

            CurrentFetchRequest currentFetchRequest = new CurrentFetchRequest(id, responseListener);
            queue = Volley.newRequestQueue(context);
            queue.add(currentFetchRequest);




        }
    };

    public Adapter(Context context,RecyclerView recyclerView){
        this.context = context;
        this.recyclerView = recyclerView;
        this.inflater = LayoutInflater.from(context);
        dataList = new ArrayList<TData>();
        tempList = new ArrayList<TData>();

        dataList = null;
        tempList = null;
    }


    public Adapter(final Context context, JSONArray list, RecyclerView recyclerView){
        this.context = context;
        this.list = list;
        this.recyclerView = recyclerView;
        this.inflater = LayoutInflater.from(context);

        dataList = new ArrayList<TData>();
        tempList = new ArrayList<TData>();
        final ImageView profilePic;

        for(int i=0;i<list.length();i++){
            TData temp = new TData();
            try {
                temp.date = list.getJSONObject(i).getString("date");
                temp.email = list.getJSONObject(i).getString("email");
                temp.name = list.getJSONObject(i).getString("name");
                temp.surname = list.getJSONObject(i).getString("surname");
                temp.subject = list.getJSONObject(i).getString("subject");
                temp.max = list.getJSONObject(i).getString("max");
                temp.price = list.getJSONObject(i).getString("price");
                temp.location = list.getJSONObject(i).getString("location");
                temp.current = list.getJSONObject(i).getString("current");
                temp.id = list.getJSONObject(i).getString("id");


            } catch (JSONException e) {
                e.printStackTrace();
            }

            dataList.add(temp);
            tempList.add(temp);
        }
    }


    public void filter(String text) {
        tempList.clear();
        if(text.isEmpty()){
            tempList.addAll(dataList);
        } else{
            text = text.toLowerCase();
            for(TData item: dataList){
                if(item.name.toLowerCase().contains(text)  || item.surname.toLowerCase().contains(text)
                                                            || item.subject.toLowerCase().contains(text)
                                                            || item.date.toLowerCase().contains(text)){
                    tempList.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View row = inflater.inflate(R.layout.custom_row, parent, false);
        row.setOnClickListener(onClickListener);
        Item item = new Item(row);
        return item;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ((Item)holder).textView1.setText(tempList.get(position).name +" "+tempList.get(position).surname);
        ((Item)holder).textView2.setText(tempList.get(position).date);
        ((Item)holder).textView3.setText(tempList.get(position).subject);


        final ImageView profilePic = ((Item)holder).imageView;


        //fetch dell'url dell'immagine da database e load nella corrispondente ImageView
        Response.Listener<String> responseListenerImage = new Response.Listener<String>() {
            @Override
            public void onResponse(String response){
                try{
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        url = jsonResponse.getString("url");
                        if(!url.isEmpty()) {
                            //image load

                            Glide.with(context)
                                    .load(url)
                                    .transform(new CircleTransform(context))
                                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                                    .signature(new StringSignature(Long.toString(System.currentTimeMillis() / (1000))) )
                                    .into(profilePic);


                        }else{
                            Glide.with(context)
                                    .load("https://webdev.dibris.unige.it/~S4078526/Tutors/ProfilePics/user.png")
                                    .transform(new CircleTransform(context))
                                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                                    .into(profilePic);

                        }
                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        };




        FetchImageUrlRequest fetchImageUrlRequest = new FetchImageUrlRequest(tempList.get(position).email,responseListenerImage);
        queue = Volley.newRequestQueue(context);
        queue.add(fetchImageUrlRequest);



        }



    @Override
    public int getItemCount() {
        if(tempList == null) return 0;
        return tempList.size();
    }


    public class Item extends RecyclerView.ViewHolder{
        TextView textView1,textView2,textView3;
        ImageView imageView;

        public Item(View itemView){
            super(itemView);
            textView1 =  itemView.findViewById(R.id.item1);
            textView2 =  itemView.findViewById(R.id.item2);
            textView3 =  itemView.findViewById(R.id.item3);
            imageView =  (ImageView) itemView.findViewById(R.id.image_view_list);

        }
    }
}
