package com.example.andrearaffo.tutors;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Created by Andrea Raffo on 19/12/2017.
 */

public class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    JSONArray list;
    RecyclerView recyclerView;
    ArrayList<TData> dataList;
    ArrayList<TData> tempList;

    private final View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int itemPosition = recyclerView.getChildLayoutPosition(v);

            String subject = tempList.get(itemPosition).subject;

            Bundle data = new Bundle();
            data.putString("subject", subject);

            FragmentManager fragmentManager = ((Activity) context).getFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            InfoFragment infoFragment = new InfoFragment();
            infoFragment.setArguments(data);
            transaction.replace(R.id.content,infoFragment).commit();

        }
    };

    public Adapter(Context context, JSONArray list,RecyclerView recyclerView){
        this.context = context;
        this.list = list;
        this.recyclerView = recyclerView;

        dataList = new ArrayList<TData>();
        tempList = new ArrayList<TData>();

        for(int i=0;i<list.length();i++){
            TData temp = new TData();
            try {
                temp.date = list.getJSONObject(i).getString("date");
                temp.subject = list.getJSONObject(i).getString("subject");
                temp.username = list.getJSONObject(i).getString("username");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            dataList.add(temp);
            tempList.add(temp);
        }
    }


    public void filter(String text) {
        tempList.clear();
        if(text.isEmpty()){
            tempList.addAll(dataList);
        } else{
            text = text.toLowerCase();
            for(TData item: dataList){
                if(item.username.toLowerCase().contains(text) || item.subject.toLowerCase().contains(text)
                                                              || item.date.toLowerCase().contains(text)){
                    tempList.add(item);
                }
            }
        }

        notifyDataSetChanged();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View row = inflater.inflate(R.layout.custom_row, parent, false);
        row.setOnClickListener(onClickListener);
        Item item = new Item(row);
        return item;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ((Item)holder).textView1.setText(tempList.get(position).date);
        ((Item)holder).textView2.setText(tempList.get(position).username);
        ((Item)holder).textView3.setText(tempList.get(position).subject);


    }

    @Override
    public int getItemCount() {
        return tempList.size();
    }


    public class Item extends RecyclerView.ViewHolder{
        TextView textView1,textView2,textView3;

        public Item(View itemView){
            super(itemView);
            textView1 =  itemView.findViewById(R.id.item1);
            textView2 =  itemView.findViewById(R.id.item2);
            textView3 =  itemView.findViewById(R.id.item3);

        }
    }
}
