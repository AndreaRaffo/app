package com.example.andrearaffo.tutors;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by Andrea Raffo on 10/01/2018.
 */

public class AdapterNotes extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    JSONArray list;
    RecyclerView recyclerView;
    ArrayList<NData> dataList;
    ArrayList<NData> tempList;
    String balance;

    private final View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            final int itemPosition = recyclerView.getChildLayoutPosition(v);
            final String price = tempList.get(itemPosition).price;
            final String path = tempList.get(itemPosition).path;
            final String fileName = tempList.get(itemPosition).fileName;
            //email di chi riceve il pagamento
            final String paidUserEmail = tempList.get(itemPosition).email;

            final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Vuoi spendere " + price + " CRYPTOPALANCHE ?");
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Si", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {
                    if(Integer.parseInt(balance)>= Integer.parseInt(price)) {
                        int temp =  Integer.parseInt(balance);
                        temp -= Integer.parseInt(price);

                        //email dell'utente che sta pagando
                        SharedPreferences sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
                        String email = sharedPref.getString("email","");


                        SharedPreferences.Editor prefEditor = sharedPref.edit();
                        prefEditor.putString("balance", Integer.toString(temp));
                        prefEditor.apply();
                        balance = Integer.toString(temp);


                        Response.Listener<String> responseListener = new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response){
                                try{
                                    JSONObject jsonResponse = new JSONObject(response);
                                    boolean success = jsonResponse.getBoolean("success");
                                    if(success){
                                        Toast.makeText(context, "Credito rimasto: " + jsonResponse.getString("balance"),
                                                Toast.LENGTH_SHORT).show();
                                        alertDialog.dismiss();
                                    }
                                }catch(JSONException e){
                                    e.printStackTrace();
                                }
                            }
                        };


                        UpdateBalanceRequest updateBalanceRequest = new UpdateBalanceRequest(email,paidUserEmail,balance,price,responseListener);
                        RequestQueue queue = Volley.newRequestQueue(context);
                        queue.add(updateBalanceRequest);

                        downloadPdf(path, fileName);

                    }else{
                        Toast.makeText(context, "Credito insufficiente",
                                Toast.LENGTH_SHORT).show();
                        alertDialog.dismiss();
                    }

                }});

            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "No", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int id) {
                    alertDialog.dismiss();

                } });

            alertDialog.show();

        }
    };

    public static boolean isDownloadManagerAvailable(Context context) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            return true;
        }
        return false;
    }

    public void downloadPdf(String path,String fileName){

        String url = path;
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        //request.setDescription("Some descrition");
        request.setTitle(fileName +".pdf");
        // in order for this if to run, you must use the android 3.2 to compile your app
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            request.allowScanningByMediaScanner();
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        }
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName +".pdf");

        // get download service and enqueue file
        DownloadManager manager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        manager.enqueue(request);
    }



    public AdapterNotes(Context context, JSONArray list,RecyclerView recyclerView){
        SharedPreferences sharedPref = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        this.context = context;
        this.list = list;
        this.recyclerView = recyclerView;
        this.balance = sharedPref.getString("balance","");

        dataList = new ArrayList<NData>();
        tempList = new ArrayList<NData>();

        for(int i=0;i<list.length();i++){
            NData temp = new NData();
            try {
                temp.year = list.getJSONObject(i).getString("year");
                temp.fileName = list.getJSONObject(i).getString("fileName");
                temp.name = list.getJSONObject(i).getString("name");
                temp.surname = list.getJSONObject(i).getString("surname");
                temp.price = list.getJSONObject(i).getString("price");
                temp.subject = list.getJSONObject(i).getString("subject");
                temp.email = list.getJSONObject(i).getString("email");
                temp.path = list.getJSONObject(i).getString("path");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            dataList.add(temp);
            tempList.add(temp);
        }
    }


    public void filter(String text) {
        tempList.clear();
        if(text.isEmpty()){
            tempList.addAll(dataList);
        } else{
            text = text.toLowerCase();
            for(NData item: dataList){
                if(item.name.toLowerCase().contains(text) || item.surname.toLowerCase().contains(text)
                                                          || item.fileName.toLowerCase().contains(text)
                                                          || item.year.toLowerCase().contains(text)
                                                          || item.subject.toLowerCase().contains(text)){
                    tempList.add(item);
                }
            }
        }

        notifyDataSetChanged();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View row = inflater.inflate(R.layout.custom_row_notes, parent, false);
        row.setOnClickListener(onClickListener);
        Item item = new Item(row);
        return item;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        ((Item)holder).textView1.setText(tempList.get(position).fileName);
        ((Item)holder).textView2.setText(tempList.get(position).subject);
        ((Item)holder).textView3.setText(tempList.get(position).name + " " +tempList.get(position).surname);
        ((Item)holder).textView4.setText(tempList.get(position).year);
        ((Item)holder).textView5.setText(tempList.get(position).price + " CRYPTOPALANCHE");

    }

    @Override
    public int getItemCount() {
        return tempList.size();
    }


    public class Item extends RecyclerView.ViewHolder{
        TextView textView1,textView2,textView3,textView4,textView5;

        public Item(View itemView){
            super(itemView);
            textView1 =  itemView.findViewById(R.id.item1);
            textView2 =  itemView.findViewById(R.id.item2);
            textView3 =  itemView.findViewById(R.id.item3);
            textView4 =  itemView.findViewById(R.id.item4);
            textView5 =  itemView.findViewById(R.id.item5);

        }
    }
}
