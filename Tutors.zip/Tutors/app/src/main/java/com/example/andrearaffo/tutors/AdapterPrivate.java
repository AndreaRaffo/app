package com.example.andrearaffo.tutors;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Created by Andrea Raffo on 19/12/2017.
 */

public class AdapterPrivate extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    JSONArray list;
    RecyclerView recyclerView;
    ArrayList<PData> dataList;
    ArrayList<PData> tempList;



    public AdapterPrivate(Context context,RecyclerView recyclerView){
        this.context = context;
        this.recyclerView = recyclerView;

        dataList = new ArrayList<PData>();
        tempList = new ArrayList<PData>();

        dataList = null;
        tempList = null;
    }



    public AdapterPrivate(Context context, JSONArray list,RecyclerView recyclerView){
        this.context = context;
        this.list = list;
        this.recyclerView = recyclerView;

        dataList = new ArrayList<PData>();
        tempList = new ArrayList<PData>();



        for(int i=0;i<list.length();i++){
            PData temp = new PData();
            try {
                temp.name = list.getJSONObject(i).getString("name");
                temp.surname = list.getJSONObject(i).getString("surname");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            dataList.add(temp);
            tempList.add(temp);

        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View row = inflater.inflate(R.layout.custom_private_row, parent, false);
        Item item = new Item(row);
        return item;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        String name = tempList.get(position).name;
        String surname = tempList.get(position).surname;

        ((Item)holder).textView1.setText(name + " " + surname);
    }

    @Override
    public int getItemCount() {
        return tempList.size();
    }


    public class Item extends RecyclerView.ViewHolder{
        TextView textView1;

        public Item(View itemView){
            super(itemView);
            textView1 =  itemView.findViewById(R.id.PItem1);

        }
    }
}

