package com.example.andrearaffo.tutors;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.DialogPreference;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Created by Andrea Raffo on 18/01/2018.
 */
public class CustomPreference extends DialogPreference implements DialogInterface.OnClickListener{

    public String oldP;
    public String newP;
    public String confP;
    EditText oldPsw;
    EditText newPsw;
    EditText confirmPsw;


    public CustomPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onBindDialogView(View view) {
        super.onBindDialogView(view);
    }

    @Override
    protected void onDialogClosed(boolean positiveResult) {
        super.onDialogClosed(positiveResult);
    }

    protected View onCreateDialogView() {
        View v = LayoutInflater.from(getContext()).inflate(R.layout.custom_change_password, null);

        oldPsw = v.findViewById(R.id.oldPswEditText);
        newPsw = v.findViewById(R.id.newPswEditText);
        confirmPsw = v.findViewById(R.id.confirmPswEditText);

        return v;
    }


    @Override
    public void onClick(DialogInterface dialog, int which) {
        super.onClick(dialog, which);

        if(which == DialogInterface.BUTTON_POSITIVE) {
            oldP = oldPsw.getText().toString().trim();
            newP = newPsw.getText().toString().trim();
            confP = confirmPsw.getText().toString().trim();

            Log.d("LUL",oldP);
            Log.d("LUL",newP);
            Log.d("LUL",confP);


            if(oldP.isEmpty()){
                Toast.makeText(getContext(), "Errore, password richiesta", Toast.LENGTH_SHORT).show();
                return;
            }

            if(newP.isEmpty()){
                Toast.makeText(getContext(), "Errore, password richiesta", Toast.LENGTH_SHORT).show();
                return;
            }

            if(confP.isEmpty()){
                Toast.makeText(getContext(), "Errore, password richiesta", Toast.LENGTH_SHORT).show();
                return;
            }


            if(newP.length()<6){
                Toast.makeText(getContext(), "Errore, la nuova password deve avere almeno 6 caratteri", Toast.LENGTH_SHORT).show();
                return;
            }

            if(!newP.equals(confP)){
                Toast.makeText(getContext(), "Errore, le password non corrispondono", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences sharedPref = getContext().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
            final String email = sharedPref.getString("email","");

            final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            AuthCredential credential = EmailAuthProvider
                    .getCredential(email, oldP);

            // Prompt the user to re-provide their sign-in credentials
            user.reauthenticate(credential)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                user.updatePassword(newP).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(getContext(), "Password modificata con successo", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(getContext(), "Errore, modifica password non riuscita", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                            } else {
                                Toast.makeText(getContext(), "Errore, password non valida", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

        }else if(which == DialogInterface.BUTTON_NEGATIVE){
            getDialog().dismiss();
        }

    }
}
