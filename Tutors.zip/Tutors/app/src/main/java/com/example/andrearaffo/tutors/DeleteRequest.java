package com.example.andrearaffo.tutors;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 16/01/2018.
 */

public class DeleteRequest extends StringRequest {

    private static final String DELETE_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/delete_lesson.php";
    private Map<String,String> params;

    public DeleteRequest(String ID, Response.Listener<String> listener) {
        super(Request.Method.POST, DELETE_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("ID",ID);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }

}
