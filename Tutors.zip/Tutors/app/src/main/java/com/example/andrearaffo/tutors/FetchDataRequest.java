package com.example.andrearaffo.tutors;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 23/11/2017.
 */

public class FetchDataRequest extends StringRequest {

    private static final String FETCH_DATA_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/fetch_data.php";
    private Map<String,String> params;

    public FetchDataRequest(String email, Response.Listener<String> listener){
        super(Request.Method.POST, FETCH_DATA_REQUEST_URL,listener,null);
        params = new HashMap<>();
        params.put("Email",email);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
