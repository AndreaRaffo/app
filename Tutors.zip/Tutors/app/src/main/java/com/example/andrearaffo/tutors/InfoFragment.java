package com.example.andrearaffo.tutors;

import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.provider.CalendarContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link InfoFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link InfoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class InfoFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String subject;
    private String paidUserEmail;
    private String name;
    private String surname;
    private String date;
    private String max;
    private String price;
    private String location;
    private String current;
    private String lessonID;

    private ProgressDialog progressDialog;
    private RequestQueue queue;
    private OnFragmentInteractionListener mListener;

    public InfoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment InfoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static InfoFragment newInstance(String param1, String param2) {
        InfoFragment fragment = new InfoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getArguments();
        subject = extras.getString("subject");
        paidUserEmail = extras.getString("paidUserEmail");
        name = extras.getString("name");
        surname = extras.getString("surname");
        date = extras.getString("date");
        max = extras.getString("max");
        price = extras.getString("price");
        location = extras.getString("location");
        current = extras.getString("current");
        lessonID = extras.getString("id");

    }

    @Override
    public void onStart() {
        super.onStart();
        final SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        final String email = sharedPref.getString("email","");

        TextView subjectTextView = getActivity().findViewById(R.id.SubjectTextView);
        TextView nameTextView = getActivity().findViewById(R.id.nameTextView);
        TextView dateTextView = getActivity().findViewById(R.id.dateTextView);
        TextView avaiableTextView = getActivity().findViewById(R.id.avaiableTextView);
        TextView priceTextView = getActivity().findViewById(R.id.priceTextView);
        TextView locationTextView = getActivity().findViewById(R.id.locationTextView);

        final Button joinButton = getActivity().findViewById(R.id.joinButton);

        subjectTextView.setText(subject);
        nameTextView.setText(name + " " + surname);
        dateTextView.setText(date);
        avaiableTextView.setText(current+"/"+max);
        priceTextView.setText(price);
        locationTextView.setText(location);


        final AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Vuoi spendere " + price + " CRYPTOPALANCHE ?");

        final AlertDialog alertDialogUnsub = new AlertDialog.Builder(getActivity()).create();
        alertDialogUnsub.setTitle("Sei sicuro di volerti disiscrivere?");

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Si", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
               String balance = sharedPref.getString("balance","");

                //controllo della disponibilità in soldi
                if(Integer.parseInt(balance)>= Integer.parseInt(price)) {

                    //listener join
                    Response.Listener<String> joinResponseListener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response){
                            try{
                                JSONObject jsonResponse = new JSONObject(response);
                                boolean success = jsonResponse.getBoolean("success");
                                boolean duplicate = jsonResponse.getBoolean("duplicate");
                                String message;

                                if(success){
                                    message = "Iscrizione avvenuta con successo.";
                                    //se il join è andato a buon fine, effettua il pagamento

                                    //calcolo della nuova balance
                                    String balanceTemp = sharedPref.getString("balance","");
                                    int temp =  Integer.parseInt(balanceTemp);
                                    temp -= Integer.parseInt(price);
                                    balanceTemp = Integer.toString(temp);

                                    //aggiorno le sharedpref
                                    SharedPreferences.Editor prefEditor = sharedPref.edit();
                                    prefEditor.putString("balance", balanceTemp);
                                    prefEditor.apply();

                                    Response.Listener<String> responseListener = new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            try {
                                                JSONObject jsonResponse = new JSONObject(response);
                                                boolean success = jsonResponse.getBoolean("success");
                                                if (success) {
                                                    alertDialog.dismiss();
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    };

                                    UpdateBalanceRequest updateBalanceRequest = new UpdateBalanceRequest(email, paidUserEmail, balanceTemp, price, responseListener);
                                    queue = Volley.newRequestQueue(getActivity());
                                    queue.add(updateBalanceRequest);

                                }else if(duplicate){
                                    message = "Sei già iscritto a questa ripetizione.";
                                }else{
                                    message = "Iscrizione non riuscita, posti terminati.";
                                }

                                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();

                            }catch(JSONException e){
                                e.printStackTrace();
                            }
                        }
                    };

                    JoinRequest joinRequest = new JoinRequest(email,lessonID,joinResponseListener);
                    RequestQueue queue = Volley.newRequestQueue(getActivity());
                    queue.add(joinRequest);


                    //calendar
                    Date eDate = null;
                    DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
                    try {
                       eDate = df.parse(date);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    long begin = eDate.getTime();
                    addEvent(subject,location,begin);

                    }else{
                    Toast.makeText(getActivity(), "Credito insufficiente", Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }


            }});

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                alertDialog.dismiss();
            } });


        alertDialogUnsub.setButton(AlertDialog.BUTTON_NEGATIVE, "Si", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                //listener unsub
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response){
                        try{
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if(success) {
                                String message = "Ti sei disiscritto dalla ripetizione";
                                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
                            }
                            alertDialog.dismiss();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                UnsubRequest unsubRequest = new UnsubRequest(email, lessonID, responseListener);
                queue = Volley.newRequestQueue(getActivity());
                queue.add(unsubRequest);

            }});

        alertDialogUnsub.setButton(AlertDialog.BUTTON_POSITIVE, "No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                alertDialogUnsub.dismiss();
            } });



        //controllo se l'utente è già iscritto o meno alla ripetizione
        Response.Listener<String> checkResponseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean subscribed = jsonResponse.getBoolean("subscribed");
                    if (!subscribed) {

                        joinButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.show();
                            }
                        });

                    }else{
                        joinButton.setText("Disiscriviti");
                        joinButton.setVisibility(View.VISIBLE);
                        joinButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialogUnsub.show();
                            }
                        });

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };



            CheckSubRequest checkSubRequest = new CheckSubRequest(email, lessonID, checkResponseListener);
            queue = Volley.newRequestQueue(getActivity());
            queue.add(checkSubRequest);
            queue.addRequestFinishedListener(new RequestQueue.RequestFinishedListener<String>() {
                @Override
                public void onRequestFinished(Request<String> request) {
                    FrameLayout temp = getActivity().findViewById(R.id.frameLayoutInfo);
                    temp.setVisibility(View.VISIBLE);
                }
            });


    }

    public void addEvent(String title, String location, long begin) {
        Intent intent = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.Events.EVENT_LOCATION, location)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin);
        if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(intent);
        }
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_info, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
