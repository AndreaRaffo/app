package com.example.andrearaffo.tutors;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 01/01/2018.
 */

public class InsertLessonRequest extends StringRequest {

    private static final String INSERT_LESSON_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/insert_lesson.php";
    private Map <String,String> params;

    public InsertLessonRequest(String email, String subject, String date, String location, String price, String num_max, Response.Listener<String> listener){
        super(Method.POST, INSERT_LESSON_REQUEST_URL,listener,null);
        params = new HashMap<>();
        params.put("Email",email);
        params.put("Subject",subject);
        params.put("Date",date);
        params.put("Location",location);
        params.put("Price",price);
        params.put("Max",num_max);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
