package com.example.andrearaffo.tutors;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 13/01/2018.
 */

public class JoinRequest extends StringRequest {

    private static final String JOIN_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/join_lesson.php";
    private Map <String,String> params;

    public JoinRequest(String email, String id, Response.Listener<String> listener){
        super(Method.POST, JOIN_REQUEST_URL,listener,null);
        params = new HashMap<>();
        params.put("Email",email);
        params.put("ID",id);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
