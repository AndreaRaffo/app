package com.example.andrearaffo.tutors;

/**
 * Created by Andrea Raffo on 10/01/2018.
 */

public class NData {
    public String username;
    public String subject;
    public String year;
    public String name;
    public String price;
    public String path;
}
