package com.example.andrearaffo.tutors;

/**
 * Created by Andrea Raffo on 10/01/2018.
 */

public class NData {
    public String name;
    public String surname;
    public String email;
    public String subject;
    public String year;
    public String fileName;
    public String price;
    public String path;
}
