package com.example.andrearaffo.tutors;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 10/01/2018.
 */

public class NotesRequest extends StringRequest {

    private static final String NOTES_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/notes_fetch.php";

    public NotesRequest(Response.Listener<String> listener) {
        super(Request.Method.POST, NOTES_REQUEST_URL, listener, null);
    }

}