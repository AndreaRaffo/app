package com.example.andrearaffo.tutors;

/**
 * Created by Andrea Raffo on 15/01/2018.
 */

public class PData {
    public String name;
    public String surname;
}
