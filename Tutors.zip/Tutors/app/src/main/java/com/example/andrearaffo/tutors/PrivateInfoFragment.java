package com.example.andrearaffo.tutors;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class PrivateInfoFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String subject;
    private String paidUser;
    private String date;
    private String max;
    private String price;
    private String location;
    private String current;
    private String lessonID;

    private JSONArray jsonResponse;
    private RecyclerView recyclerView;
    AdapterPrivate adapter;
    private RequestQueue queue;
    private OnFragmentInteractionListener mListener;

    public PrivateInfoFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static PrivateInfoFragment newInstance(String param1, String param2) {
        PrivateInfoFragment fragment = new PrivateInfoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getArguments();
        subject = extras.getString("subject");
        paidUser = extras.getString("paidUser");
        date = extras.getString("date");
        max = extras.getString("max");
        price = extras.getString("price");
        location = extras.getString("location");
        current = extras.getString("current");
        lessonID = extras.getString("id");

    }

    @Override
    public void onStart() {
        super.onStart();
        final SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        final String username = sharedPref.getString("username","");

        TextView subjectTextView = getActivity().findViewById(R.id.PSubjectTextView);
        TextView usernameTextView = getActivity().findViewById(R.id.PUsernameTextView);
        TextView dateTextView = getActivity().findViewById(R.id.PDateTextView);
        TextView avaiableTextView = getActivity().findViewById(R.id.PAvaiableTextView);
        TextView priceTextView = getActivity().findViewById(R.id.PPriceTextView);
        TextView locationTextView = getActivity().findViewById(R.id.PLocationTextView);
        final TextView noUsersTextView = getActivity().findViewById(R.id.noUsersTextView);

        final Button joinButton = getActivity().findViewById(R.id.joinButton);

        subjectTextView.setText(subject);
        usernameTextView.setText(paidUser);
        dateTextView.setText(date);
        avaiableTextView.setText(current+"/"+max);
        priceTextView.setText(price);
        locationTextView.setText(location);

        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response){
                try{
                    jsonResponse = new JSONArray(response);
                    String success = jsonResponse.getJSONObject(0).getString("success");
                    String noUsers = jsonResponse.getJSONObject(0).getString("noUsers");

                    if(success == "true") {
                        if (noUsers == "false") {
                            recyclerView = getActivity().findViewById(R.id.recyclerViewPrivate);
                            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                            recyclerView.setVisibility(View.VISIBLE);
                            adapter = new AdapterPrivate(getActivity(), jsonResponse, recyclerView);
                            recyclerView.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                        }else{
                            noUsersTextView.setVisibility(View.VISIBLE);
                        }
                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        };

        UserListRequest userListRequest = new UserListRequest(lessonID,responseListener);
        queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        queue.add(userListRequest);



        final AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
        alertDialog.setTitle("Sei sicuro di voler eliminare questa ripetizione?");

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Si", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                Response.Listener<String> deleteResponseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response){
                        try{
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            boolean noCredit = jsonResponse.getBoolean("noCredit");

                            if(success) {

                                Toast.makeText(getActivity(), "Ripetizione eliminata",
                                        Toast.LENGTH_SHORT).show();
                            }else if(noCredit){

                                Toast.makeText(getActivity(), "Errore, credito insufficiente per il rimborso.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                };

                DeleteRequest deleteRequest = new DeleteRequest(lessonID,deleteResponseListener);
                queue = Volley.newRequestQueue(getActivity().getApplicationContext());
                queue.add(deleteRequest);
                }
            });

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                alertDialog.dismiss();
            } });


        Button deleteButton = getActivity().findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.show();
            }
        });



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_private_info, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
