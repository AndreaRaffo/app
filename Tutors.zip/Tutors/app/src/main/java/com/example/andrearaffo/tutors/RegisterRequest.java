package com.example.andrearaffo.tutors;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 21/11/2017.
 */

public class RegisterRequest extends StringRequest {

    private static final String REGISTER_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/register.php";
    private Map <String,String> params;

    public RegisterRequest(String email, String name, String surname, Response.Listener<String> listener){
        super(Method.POST, REGISTER_REQUEST_URL,listener,null);
        params = new HashMap<>();
        params.put("Email",email);
        params.put("Name",name);
        params.put("Surname",surname);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
