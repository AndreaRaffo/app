package com.example.andrearaffo.tutors;

/**
 * Created by Andrea Raffo on 19/01/2018.
 */


        import android.os.AsyncTask;

        import org.json.JSONObject;

        import java.io.BufferedReader;
        import java.io.InputStreamReader;
        import java.io.OutputStreamWriter;
        import java.net.HttpURLConnection;
        import java.net.URL;
        import java.net.URLEncoder;


public  class SendPushNotification extends AsyncTask<String, Void,Void> {


    @Override
    protected Void doInBackground(String... strings) {

       String authKey = strings[0];
       String title = strings[1];
       String body = strings[2];
       String FMCurl = "https://fcm.googleapis.com/fcm/send";

       for(int i=3; i<strings.length;i++) {
           String DeviceIdKey = strings[i];         //token dell'utente specifico (da strings[3] in poi)

           try {
               URL url = new URL(FMCurl);
               HttpURLConnection conn = (HttpURLConnection) url.openConnection();

               conn.setUseCaches(false);
               conn.setDoInput(true);
               conn.setDoOutput(true);

               conn.setRequestMethod("POST");
               conn.setRequestProperty("Authorization", "key=" + authKey);
               conn.setRequestProperty("Content-Type", "application/json");
               System.out.println(DeviceIdKey);
               JSONObject data = new JSONObject();
               data.put("to", DeviceIdKey.trim());
               JSONObject info = new JSONObject();
               info.put("title", title); // Notification title
               info.put("body", body); // Notification body
               data.put("data", info);
               System.out.println(data.toString());

               OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
               wr.write(data.toString());
               wr.flush();
               wr.close();

               int responseCode = conn.getResponseCode();
               System.out.println("Response Code : " + responseCode);

               BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
               String inputLine;
               StringBuffer response = new StringBuffer();

               while ((inputLine = in.readLine()) != null) {
                   response.append(inputLine);
               }
               in.close();

           } catch (Exception e) {
               System.out.println(e);
           }
       }

        return null;
    }
}
