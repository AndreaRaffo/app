package com.example.andrearaffo.tutors;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.app.Fragment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.os.Handler;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.signature.StringSignature;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;


import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.UploadNotificationConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SettingsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SettingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */

public class SettingsFragment extends PreferenceFragment implements Preference.OnPreferenceChangeListener {



    private OnFragmentInteractionListener mListener;
    private ImageView profilePic;
    //Image request code
    private int PICK_IMAGE_REQUEST = 1;
    public final String IMAGE_UPLOAD_HTTP_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/image_upload.php";

    //storage permission code
    private static final int STORAGE_PERMISSION_CODE = 123;

    //Bitmap to get image from gallery
    private Bitmap bitmap;

    //Uri to store the image uri
    private Uri filePath;
    private RequestQueue queue;
    ProgressBar progressBar;



    public SettingsFragment() {
    }


    public static SettingsFragment newInstance(String param1, String param2) {
        SettingsFragment fragment = new SettingsFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    private void modifyPref(SharedPreferences sharedPref, String sKey){
        EditTextPreference editTextPreference=(EditTextPreference) findPreference(sKey);
        String tempS = sharedPref.getString(sKey,"");
        editTextPreference.setOnPreferenceChangeListener(this);
        editTextPreference.setSummary(tempS);
        editTextPreference.setText(tempS);
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);
        ((MainActivity) getActivity()).setActionBarTitle("Profilo");



        //logout
        Preference button = findPreference(getString(R.string.logout));
        button.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                FirebaseAuth.getInstance().signOut();
                getActivity().finish();
                startActivity(new Intent(getActivity(),LoginActivity.class));
                return true;
            }
        });


        final SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        final String prefEmail = sharedPref.getString("email","");


        //fetch Balance from user
        Response.Listener<String> responseListenerBalance = new Response.Listener<String>() {
            @Override
            public void onResponse(String response){
                try{
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        String balance = jsonResponse.getString("Balance");
                        SharedPreferences.Editor prefEditor = sharedPref.edit();
                        prefEditor.putString("balance",balance);
                        prefEditor.apply();
                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        };

        FetchBalanceRequest fetchBalanceRequest = new FetchBalanceRequest(prefEmail,responseListenerBalance);
        queue = Volley.newRequestQueue(getActivity());
        queue.add(fetchBalanceRequest);


        //custom preference
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar = (ProgressBar) getActivity().findViewById(R.id.progressbar);

                //fetch dell'url dell'immagine da database e load nell'ImageView
                Response.Listener<String> responseListenerImage = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response){
                        try{
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if(success){
                                profilePic = getActivity().findViewById(R.id.imageView2);
                                final String url = jsonResponse.getString("url");
                                if(url.isEmpty()){
                                    //default image
                                    Glide.with(getActivity())
                                            .load("https://webdev.dibris.unige.it/~S4078526/Tutors/ProfilePics/user.png")
                                            .transform(new CircleTransform(getActivity()))
                                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                                            .signature(new StringSignature(Long.toString(System.currentTimeMillis() / (1000))) )
                                            .listener(new RequestListener<String, GlideDrawable>() {
                                                @Override
                                                public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                                    return false;
                                                }

                                                @Override
                                                public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                                    progressBar.setVisibility(View.GONE);
                                                    profilePic.setVisibility(View.VISIBLE);
                                                    return false;
                                                }
                                            })
                                            .into(profilePic);

                                }else{
                                    //image load
                                    Glide.with(getActivity())
                                            .load(url)
                                            .transform(new CircleTransform(getActivity()))
                                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                                            .signature(new StringSignature(Long.toString(System.currentTimeMillis() / (1000))) )
                                            .listener(new RequestListener<String, GlideDrawable>() {
                                                @Override
                                                public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                                    return false;
                                                }

                                                @Override
                                                public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                                    progressBar.setVisibility(View.GONE);
                                                    profilePic.setVisibility(View.VISIBLE);
                                                    return false;
                                                }
                                            })
                                            .into(profilePic);
                                }
                            }
                        }catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                };

                progressBar.setVisibility(View.VISIBLE);
                FetchImageUrlRequest fetchImageUrlRequest = new FetchImageUrlRequest(prefEmail,responseListenerImage);
                queue = Volley.newRequestQueue(getActivity().getApplicationContext());
                queue.add(fetchImageUrlRequest);


                //modifica dell'immagine di profilo (onclick sull'ImageView)
                profilePic = getActivity().findViewById(R.id.imageView2);
                profilePic.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        requestStoragePermission();
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_GET_CONTENT);
                        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);

                    }
                });

                String balance = sharedPref.getString("balance","");
                String name = sharedPref.getString("name","");
                String surname = sharedPref.getString("surname","");
                TextView balanceTextView =  getActivity().findViewById(R.id.balanceTextView);
                TextView nameTextView =  getActivity().findViewById(R.id.namePreference);
                TextView emailTextView = getActivity().findViewById(R.id.emailPreference);
                balanceTextView.setText(balance);
                nameTextView.setText(name + " " + surname);
                emailTextView.setText(prefEmail);
            }
        }, 50);


        modifyPref(sharedPref,"name");
        modifyPref(sharedPref,"surname");

        EditTextPreference ETPpassword=(EditTextPreference) findPreference("password");


    }


    @Override
    public void onStart() {
        super.onStart();

    }

    //Requesting permission
    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        //And finally ask for the permission
        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }




    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        }
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }




    @Override
    public boolean onPreferenceChange(Preference prefs, final Object newValue) {
        SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedPref.edit();
        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response){
                try{
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if(!success){
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity().getApplicationContext());
                        builder.setMessage("Modifica non riuscita")
                                .create()
                                .show();
                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        };

        switch (prefs.getKey()) {
            case "name":
                prefEditor.putString("name", (String) newValue);
                prefEditor.apply();
                EditTextPreference ETPname=(EditTextPreference) findPreference("name");
                ETPname.setSummary((String) newValue);
                ETPname.setText((String) newValue);
                break;
            case "surname":
                prefEditor.putString("surname", (String) newValue);
                prefEditor.apply();
                EditTextPreference ETPsurname=(EditTextPreference) findPreference("surname");
                ETPsurname.setSummary((String) newValue);
                ETPsurname.setText((String) newValue);
                break;

            default:
                break;
        }


        String name = sharedPref.getString("name","");
        String surname = sharedPref.getString("surname","");
        String email = sharedPref.getString("email","");

        Log.d("LUL",name + " " + surname + " " + email);


        SettingsRequest settingsRequest = new SettingsRequest(name,surname,email,responseListener);
        queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        queue.add(settingsRequest);

        return false;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);


            }

    public void uploadMultipart() {
        //getting the actual path of the image
        String path = getPath(filePath);

        //Uploading code
        try {
            String uploadId = UUID.randomUUID().toString();
            SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
            String email = sharedPref.getString("email","");
            //Creating a multi part request
            new MultipartUploadRequest(getActivity(), uploadId, IMAGE_UPLOAD_HTTP_URL)
                    .addFileToUpload(path, "image") //Adding file
                    .addParameter("Email", email) //Adding  parameter to the request
                    .setNotificationConfig(new UploadNotificationConfig())
                    .setMaxRetries(2)
                    .startUpload(); //Starting the upload

        } catch (Exception exc) {
            Toast.makeText(getActivity(), exc.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }



    //handling the image chooser activity result
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filePath);
                final Uri uri = getImageUri(getActivity(),bitmap);
                Glide.with(getActivity())
                        .load(uri)
                        .transform(new CircleTransform(getActivity()))
                        .signature(new StringSignature(Long.toString(System.currentTimeMillis() / (1000))) )
                        .into(profilePic);
                profilePic.setVisibility(View.VISIBLE);
                uploadMultipart();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //method to get the file path from uri
    public String getPath(Uri uri) {
        Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        String document_id = cursor.getString(0);
        document_id = document_id.substring(document_id.lastIndexOf(":") + 1);
        cursor.close();

        cursor = getActivity().getContentResolver().query(
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                null, MediaStore.Images.Media._ID + " = ? ", new String[]{document_id}, null);
        cursor.moveToFirst();
        String path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
        cursor.close();

        return path;
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }


}
