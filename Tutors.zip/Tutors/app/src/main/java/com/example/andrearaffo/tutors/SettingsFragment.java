package com.example.andrearaffo.tutors;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.app.Fragment;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.os.Handler;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;




/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link SettingsFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link SettingsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */

public class SettingsFragment extends PreferenceFragment implements Preference.OnPreferenceChangeListener {



    private OnFragmentInteractionListener mListener;




    private List<View> getAllChildren(View vi) {

        if (!(vi instanceof ViewGroup)) {
            ArrayList<View> viewArrayList = new ArrayList<View>();
            viewArrayList.add(vi);
            return viewArrayList;
        }

        ArrayList<View> result = new ArrayList<View>();

        ViewGroup viewGroup = (ViewGroup) vi;
        for (int i = 0; i < viewGroup.getChildCount(); i++) {

            View child = viewGroup.getChildAt(i);

            //Do not add any parents, just add child elements
            result.addAll(getAllChildren(child));
        }
        return result;
    }

    public SettingsFragment() {
        // Required empty public constructor
    }


    public static SettingsFragment newInstance(String param1, String param2) {
        SettingsFragment fragment = new SettingsFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    private void modifyPref(SharedPreferences sharedPref, String sKey){
        EditTextPreference editTextPreference=(EditTextPreference) findPreference(sKey);
        String tempS = sharedPref.getString(sKey,"");
        editTextPreference.setOnPreferenceChangeListener(this);
        editTextPreference.setSummary(tempS);
        editTextPreference.setText(tempS);
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);

        Preference button = findPreference(getString(R.string.logout));
        button.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                FirebaseAuth.getInstance().signOut();
                getActivity().finish();
                startActivity(new Intent(getActivity(),LoginActivity.class));
                return true;
            }
        });

        final SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        final String prefEmail = sharedPref.getString("email","");

        //fetch Balance from user
        Response.Listener<String> responseListenerBalance = new Response.Listener<String>() {
            @Override
            public void onResponse(String response){
                try{
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        String balance = jsonResponse.getString("Balance");
                        SharedPreferences.Editor prefEditor = sharedPref.edit();
                        prefEditor.putString("balance",balance);
                        prefEditor.apply();
                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        };

        FetchBalanceRequest fetchBalanceRequest = new FetchBalanceRequest(prefEmail,responseListenerBalance);
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(fetchBalanceRequest);


        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String balance = sharedPref.getString("balance","");
                String name = sharedPref.getString("name","");
                String surname = sharedPref.getString("surname","");
                TextView balanceTextView =  getActivity().findViewById(R.id.balanceTextView);
                TextView nameTextView =  getActivity().findViewById(R.id.namePreference);
                TextView emailTextView = getActivity().findViewById(R.id.emailPreference);
                balanceTextView.setText(balance);
                nameTextView.setText(name + " " + surname);
                emailTextView.setText(prefEmail);
            }
        }, 50);


        modifyPref(sharedPref,"name");
        modifyPref(sharedPref,"surname");

        EditTextPreference ETPpassword=(EditTextPreference) findPreference("password");


    }



    // TODO: Rename method, update argument and hook method into UI event


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }




    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        }
        TextView myTextView = (TextView) getActivity().findViewById(R.id.usernamePreference);
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }




    @Override
    public boolean onPreferenceChange(Preference prefs, final Object newValue) {
        SharedPreferences sharedPref = getActivity().getSharedPreferences("userInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedPref.edit();
        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response){
                try{
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");

                    if(!success){
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity().getApplicationContext());
                        builder.setMessage("Modifica non riuscita")
                                .create()
                                .show();
                    }
                }catch(JSONException e){
                    e.printStackTrace();
                }
            }
        };

        switch (prefs.getKey()) {
            case "name":
                prefEditor.putString("name", (String) newValue);
                prefEditor.apply();
                EditTextPreference ETPname=(EditTextPreference) findPreference("name");
                ETPname.setSummary((String) newValue);
                ETPname.setText((String) newValue);
                break;
            case "surname":
                prefEditor.putString("surname", (String) newValue);
                prefEditor.apply();
                EditTextPreference ETPsurname=(EditTextPreference) findPreference("surname");
                ETPsurname.setSummary((String) newValue);
                ETPsurname.setText((String) newValue);
                break;

            default:
                break;
        }

        String name = sharedPref.getString("name","");
        String surname = sharedPref.getString("surname","");
        String email = sharedPref.getString("email","");


        SettingsRequest settingsRequest = new SettingsRequest(email,name,surname,responseListener);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        queue.add(settingsRequest);

        return false;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);


            }
}
