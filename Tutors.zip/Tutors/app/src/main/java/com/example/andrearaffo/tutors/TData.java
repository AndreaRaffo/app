package com.example.andrearaffo.tutors;

/**
 * Created by Andrea Raffo on 27/12/2017.
 */

public class TData {
    public String email;
    public String name;
    public String surname;
    public String subject;
    public String date;
    public String max;
    public String price;
    public String location;
    public String current;
    public String id;

}
