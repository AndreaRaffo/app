package com.example.andrearaffo.tutors;

/**
 * Created by Andrea Raffo on 27/12/2017.
 */

public class TData {
    public String username;
    public String subject;
    public String date;

}
