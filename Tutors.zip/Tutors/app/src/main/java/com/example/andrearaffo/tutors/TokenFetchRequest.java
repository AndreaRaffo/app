package com.example.andrearaffo.tutors;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 19/01/2018.
 */

public class TokenFetchRequest extends StringRequest {

    private static final String TOKEN_FETCH_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/token_fetch.php";
    private Map<String,String> params;

    public TokenFetchRequest(String id, Response.Listener<String> listener) {
        super(Request.Method.POST, TOKEN_FETCH_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("ID",id);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }

}
