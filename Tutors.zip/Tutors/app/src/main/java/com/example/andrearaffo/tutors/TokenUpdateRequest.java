package com.example.andrearaffo.tutors;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 18/01/2018.
 */

public class TokenUpdateRequest extends StringRequest {

    private static final String TOKEN_UPDATE_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/token_update.php";
    private Map<String,String> params;

    public TokenUpdateRequest(String email, String token, Response.Listener<String> listener) {
        super(Request.Method.POST, TOKEN_UPDATE_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("Email",email);
        params.put("Token",token);


    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }

}
