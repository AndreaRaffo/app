package com.example.andrearaffo.tutors;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 18/12/2017.
 */

public class TutoringRequest extends StringRequest {

    private static final String TUTORING_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/tutoring_fetch.php";

    public TutoringRequest(Response.Listener<String> listener) {
        super(Request.Method.POST, TUTORING_REQUEST_URL, listener, null);
    }

}