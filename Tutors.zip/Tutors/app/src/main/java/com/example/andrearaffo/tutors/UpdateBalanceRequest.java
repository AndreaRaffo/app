package com.example.andrearaffo.tutors;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Andrea Raffo on 11/01/2018.
 */

public class UpdateBalanceRequest extends StringRequest {

    private static final String UPDATE_BALANCE_REQUEST_URL = "https://webdev.dibris.unige.it/~S4078526/Tutors/PHP/balance_update.php";
    private Map<String,String> params;

    public UpdateBalanceRequest(String username, String paidUser, String balance, String price, Response.Listener<String> listener) {
        super(Request.Method.POST, UPDATE_BALANCE_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("Username",username);
        params.put("PaidUser",paidUser);
        params.put("Balance",balance);
        params.put("Price",price);


    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }

}
